const ZoneManager = require('../../utils/ZoneManager');

module.exports = {
    name: 'zav',
    description: 'List attackable zones',
    execute: async (client, config, args, player) => {
        const attackableZones = ZoneManager.getAttackableZonesByGroup();
        
        if (Object.keys(attackableZones).length === 0) {
            return ' No attackable zones at this time';
        }
        
        // Build group-tag/count pairs
        const groupEntries = [];
        for (const [groupName, zones] of Object.entries(attackableZones)) {
            const tag = ZoneManager.getGroupTag(groupName) || groupName;
            groupEntries.push(`${tag} ${zones.length}`);
        }
        
        // Format the response
        let response = ' Available Zones: ';
        const messages = [];
        let currentLine = response;
        
        for (const entry of groupEntries) {
            const separator = currentLine === response ? '' : ' | ';
            const candidate = separator + entry;
            
            currentLine += candidate;
        }
        

        
        return currentLine;
    }
};
const axios = require('axios');
const config = require('../../config.json');
const ZoneManager = require('../../utils/ZoneManager');

module.exports = {
    name: 'gzt',
    description: 'Check group war timer',
    execute: async (client, config, args, player, playerId) => {
        // First check if own group is in war
        const ownGroup = config.defaultGroup;
        const opponent = ZoneManager.getGroupWarStatus(ownGroup);
        if (!opponent) {
            return '⚔️ Your group is not currently in a war.';
        }

        return new Promise(async (resolve) => {
            let timer = null;
            let attackerScore = null;
            let defenderScore = null;
            
            // Handler for textdraw events
            const textdrawHandler = (event) => {
                // Check for specific textdraw ID 60
                if (event.type === 'textdraw' && event.id === 59) {
                    // Example: "~r~~h~15~w~-~b~~h~10 ~n~~w~09:56"
                    const match = event.text.match(/~r~~h~(\d+)~w~-~b~~h~(\d+)\s*~n~~w~(\d+:\d+)/);
                    if (match) {
                        attackerScore = match[1];
                        defenderScore = match[2];
                        timer = match[3];
                        console.log(`[GZT] Parsed timer: ${attackerScore}-${defenderScore} ${timer}`);
                    }
                }
            };
            
            // Set up the handler first
            client.on('samp_event', textdrawHandler);
            
            // Set timeout
            const timeout = setTimeout(() => {
                client.off('samp_event', textdrawHandler);
                if (!timer) {
                    resolve('❌ Failed to retrieve war timer');
                } else {
                    resolve(`⏱️ War Timer: ${timer} | Score: ${attackerScore}-${defenderScore}`);
                }
                
                // Always try to leave GZ2
                axios.post(
                    `http://${config.raksampHost}:${config.raksampPort}/`,
                    `command=${encodeURIComponent('/fr')}`,
                    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
                ).catch(() => {});
            }, 5000);
            
            try {
                // Join GZ2 to see timer
                await axios.post(
                    `http://${config.raksampHost}:${config.raksampPort}/`,
                    `command=${encodeURIComponent('/gz2')}`,
                    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
                );
            } catch (e) {
                client.off('samp_event', textdrawHandler);
                clearTimeout(timeout);
                resolve('❌ Failed to join GZ2 for timer');
            }
        });
    }
};
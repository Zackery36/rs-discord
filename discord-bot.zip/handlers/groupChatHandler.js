const fs = require('fs');
const path = require('path');
const axios = require('axios');
const PlayerManager = require('../utils/PlayerManager');
const config = require('../config.json');

// Helper to safely split messages considering character limits
function splitLongMessage(message, maxLength = 110) {
    if (!message) return [];
    const chunks = [];
    let currentChunk = '';
    
    const words = message.split(' ');
    for (const word of words) {
        // Calculate new length if we add this word
        const newLength = currentChunk.length + 
                         (currentChunk ? 1 : 0) + // Space if not first word
                         word.length;
        
        if (newLength > maxLength) {
            // If current chunk has content, push it
            if (currentChunk) chunks.push(currentChunk.trim());
            
            // Handle very long words
            if (word.length > maxLength) {
                // Split the long word into chunks
                let start = 0;
                while (start < word.length) {
                    chunks.push(word.substring(start, start + maxLength));
                    start += maxLength;
                }
                currentChunk = '';
            } else {
                currentChunk = word;
            }
        } else {
            currentChunk += (currentChunk ? ' ' : '') + word;
        }
    }
    
    if (currentChunk) chunks.push(currentChunk.trim());
    return chunks;
}

// Load commands from admin, normal, and fun folders
const igCommands = {
    admin: {},
    normal: {},
    fun: {}
};

['admin', 'normal', 'fun'].forEach(category => {
    const commandPath = path.join(__dirname, `../igcmds/${category}`);
    if (fs.existsSync(commandPath)) {
        fs.readdirSync(commandPath).forEach(file => {
            if (file.endsWith('.js')) {
                const command = require(path.join(commandPath, file));
                igCommands[category][command.name] = command;
                console.log(`[IGCMD] Loaded ${category} command: ${command.name}`);
            }
        });
    }
});

module.exports = (client, config) => {
    const groupLogFile = path.join(__dirname, '../logs/gchat.log');
    if (!fs.existsSync(groupLogFile)) fs.writeFileSync(groupLogFile, '');
    
    client.on('samp_message', async (raw) => {
        if (raw.startsWith('(GROUP)') || raw.startsWith('GROUP:')) {
            fs.appendFileSync(groupLogFile, `${new Date().toISOString()} ${raw}\n`);
            const match = raw.match(/\(GROUP\)\s*\[(\d+)\]\s*([^:]+):\s*,(.+)$/);
            
            if (match) {
                const channelId = match[1];
                const playerWithId = match[2].trim();
                const fullCommand = match[3].trim();
                
                // Extract player ID from name(id) format
                const playerIdMatch = playerWithId.match(/\((\d+)\)$/);
                const playerId = playerIdMatch ? playerIdMatch[1] : null;
                const player = playerWithId.replace(/\(\d+\)$/, '').trim();
                
                if (player === config.botName) return;
                console.log(`[Group Command] Player: ${player} (ID: ${playerId}), Command: ${fullCommand}`);
                
                const [commandName, ...args] = fullCommand.split(' ');
                const playerInfo = PlayerManager.getPlayer(player);
                console.log(`[Command] Player: ${player}, Role: ${playerInfo.role || 'None'}`);
                
                let response = `Unknown command: ${commandName}`;
                let commandExecuted = false;
                
                try {
                    // Handle admin commands
                    if (igCommands.admin[commandName]) {
                        if (PlayerManager.hasRequiredRole(player, 'admin')) {
                            response = await igCommands.admin[commandName].execute(
                                client, config, args, player, playerId
                            );
                            commandExecuted = true;
                        } else {
                            response = "You need Leader role to use this command!";
                            commandExecuted = true;
                        }
                    }
                    
                    // Handle normal commands
                    if (!commandExecuted && igCommands.normal[commandName]) {
                        if (PlayerManager.hasRequiredRole(player, 'normal')) {
                            response = await igCommands.normal[commandName].execute(
                                client, config, args, player, playerId
                            );
                            commandExecuted = true;
                        } else {
                            response = "You need Co-Leader role to use this command!";
                            commandExecuted = true;
                        }
                    }
                    
                    // Handle fun commands
                    if (!commandExecuted && igCommands.fun[commandName]) {
                        response = await igCommands.fun[commandName].execute(
                            client, config, args, player, playerId
                        );
                        commandExecuted = true;
                    }
                } catch (e) {
                    response = `Error: ${e.message}`;
                    console.error(`[IGCMD] Error with ${commandName}:`, e);
                }
                
                try {
                    // Ensure response is an array of messages
                    const responses = Array.isArray(response) ? response : [response];
                    let totalChunks = 0;
                    
                    for (const resp of responses) {
                        if (!resp || resp.trim() === '') continue;
                        
                        // Split into chunks with safe length
                        const chunks = splitLongMessage(resp, 100); // Use 100 for safety buffer
                        totalChunks += chunks.length;
                        
                        for (const chunk of chunks) {
                            if (!chunk || chunk.trim() === '') continue;
                            
                            let attempts = 0;
                            const maxAttempts = 3;
                            let success = false;
                            
                            while (attempts < maxAttempts && !success) {
                                try {
                                    // Create safe message payload
                                    const messageContent = `!${chunk}`;
                                    const encodedMessage = encodeURIComponent(messageContent);
                                    
                                    // Validate payload length
                                    if (encodedMessage.length > 2000) {
                                        console.error(`[Response] Payload too long: ${encodedMessage.length} characters`);
                                        throw new Error('Payload too long');
                                    }
                                    
                                    // Create payload with safe length
                                    const payload = `message=${encodedMessage}`;
                                    
                                    await axios.post(
                                        `http://${config.raksampHost}:${config.raksampPort}/`,
                                        payload,
                                        {
                                            headers: { 
                                                'Content-Type': 'application/x-www-form-urlencoded',
                                                'Content-Length': Buffer.byteLength(payload)
                                            },
                                            timeout: 2000
                                        }
                                    );
                                    console.log(`[Response] Sent chunk (${chunk.length} chars): ${chunk.substring(0, 20)}...`);
                                    success = true;
                                } catch (e) {
                                    attempts++;
                                    const errorMsg = e.response ? 
                                        `${e.message} - ${e.response.data}` : 
                                        e.message;
                                    
                                    console.error(`[Response] Attempt ${attempts}/${maxAttempts} failed: ${errorMsg}`);
                                    
                                    if (attempts >= maxAttempts) {
                                        console.error('Failed to send response after 3 attempts');
                                    } else {
                                        // Exponential backoff for retries
                                        const delay = 500 * Math.pow(2, attempts);
                                        await new Promise(resolve => setTimeout(resolve, delay));
                                    }
                                }
                            }
                            
                            // Add delay between chunks to prevent flooding
                            await new Promise(resolve => setTimeout(resolve, 300));
                        }
                    }
                    
                    console.log(`[Command Response] ${player}: ${commandName} → Sent ${totalChunks} chunks`);
                } catch (e) {
                    console.error('[Response] Failed to process response:', e);
                }
            }
        }
    });
};
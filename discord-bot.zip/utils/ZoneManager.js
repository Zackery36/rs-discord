const fs = require('fs');
const path = require('path');

class ZoneManager {
    constructor() {
        this.zones = new Map();
        this.cooldowns = new Map();
        this.groupTags = new Map();
        this.groupZones = new Map();
        this.zoneCycles = new Map();
        this.activeWars = new Map(); // Tracks who groups are fighting against
        this.lockedAttacks = new Map();
        this.filePath = path.join(__dirname, '../data/zones.json');
        this.cooldownDuration = 6 * 60 * 60 * 1000;
        this.attackWindow = 60 * 60 * 1000;
        this.loadZones();
    }

    loadZones() {
        if (fs.existsSync(this.filePath)) {
            try {
                const data = JSON.parse(fs.readFileSync(this.filePath));
                
                // Load all data
                this.zones = new Map(data.zones || []);
                this.cooldowns = new Map(data.cooldowns || []);
                this.groupTags = new Map(data.groupTags || []);
                this.activeWars = new Map(data.activeWars || []);
                this.lockedAttacks = new Map(data.lockedAttacks || []);
                
                // Load group zones
                this.groupZones = new Map();
                if (data.groupZones) {
                    for (const [groupName, zones] of data.groupZones) {
                        this.groupZones.set(groupName, new Set(zones));
                    }
                }
                
                // Load zone cycles
                this.zoneCycles = new Map(data.zoneCycles || []);
                
                console.log(`[ZoneManager] Loaded ${this.zones.size} zones`);
            } catch (e) {
                console.error('[ZoneManager] Failed to load zones:', e);
            }
        }
    }

    saveZones() {
        // Convert data to serializable format
        const groupZonesArray = Array.from(this.groupZones.entries())
            .map(([group, zones]) => [group, Array.from(zones)]);
        
        const data = {
            zones: Array.from(this.zones.entries()),
            cooldowns: Array.from(this.cooldowns.entries()),
            groupTags: Array.from(this.groupTags.entries()),
            groupZones: groupZonesArray,
            zoneCycles: Array.from(this.zoneCycles.entries()),
            activeWars: Array.from(this.activeWars.entries()),
            lockedAttacks: Array.from(this.lockedAttacks.entries())
        };
        
        // Save to file
        fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2));
    }

    recordZoneCapture(zoneId, attackerGroup, defenderGroup) {
        const now = Date.now();
        const attackableAt = now + this.cooldownDuration;
        
        // Update zone
        this.zones.set(zoneId, {
            owner: attackerGroup,
            capturedAt: now,
            attackableAt
        });
        
        // Update group zones
        this.updateGroupZone(attackerGroup, zoneId, true);
        this.updateGroupZone(defenderGroup, zoneId, false);
        
        // Set cooldown
        this.cooldowns.set(zoneId, attackableAt);
        this.saveZones();
        
        return attackableAt;
    }

    updateGroupZone(groupName, zoneId, isAdding) {
        if (!groupName) return;
        
        const key = groupName.toLowerCase();
        let zones = this.groupZones.get(key) || new Set();
        
        if (isAdding) {
            zones.add(zoneId);
        } else {
            zones.delete(zoneId);
        }
        
        this.groupZones.set(key, zones);
        this.saveZones();
    }

    setGroupTag(groupName, tag) {
        this.groupTags.set(groupName, tag);
        this.saveZones();
    }

    getGroupTag(groupName) {
        return this.groupTags.get(groupName) || null;
    }

    addZonePosition(zoneId, x, y, z) {
        // Get or create zone
        const zone = this.zones.get(zoneId) || {};
        
        // Update position
        zone.position = { x, y, z };
        this.zones.set(zoneId, zone);
        
        // Save changes
        this.saveZones();
        
        return true;
    }

    getZonePosition(zoneId) {
        const zone = this.zones.get(zoneId);
        return zone?.position || null;
    }

    // Set group war status with opponent
    setGroupWarStatus(groupName, opponent) {
        const key = groupName.toLowerCase();
        if (opponent) {
            this.activeWars.set(key, opponent);
        } else {
            this.activeWars.delete(key);
        }
        this.saveZones();
    }

    // Get opponent group for a group
    getGroupWarStatus(groupName) {
        return this.activeWars.get(groupName.toLowerCase()) || null;
    }

    // Get group name by tag
    getGroupNameByTag(tag) {
        for (const [groupName, groupTag] of this.groupTags) {
            if (groupTag.toLowerCase() === tag.toLowerCase()) {
                return groupName;
            }
        }
        return null;
    }

    getZoneByGroupTag(tag) {
        for (const [groupName, groupTag] of this.groupTags) {
            if (groupTag.toLowerCase() === tag.toLowerCase()) {
                const zones = Array.from(this.groupZones.get(groupName) || []);
                
                // Filter attackable zones
                const attackableZones = zones.filter(zoneId => 
                    this.isAttackable(zoneId)
                );
                
                if (attackableZones.length === 0) {
                    return `${groupName} has no attackable zones`;
                }
                
                // Get or create cycle index
                const cycleKey = `${groupName}:${tag}`;
                let currentIndex = this.zoneCycles.get(cycleKey) || 0;
                
                // Get next attackable zone
                const zoneId = attackableZones[currentIndex];
                
                // Update index for next call
                currentIndex = (currentIndex + 1) % attackableZones.length;
                this.zoneCycles.set(cycleKey, currentIndex);
                this.saveZones();
                
                return zoneId;
            }
        }
        return `No group found with tag: ${tag}`;
    }

    isAttackable(zoneId) {
        const cooldown = this.cooldowns.get(zoneId);
        if (!cooldown) return true;
        
        const now = Date.now();
        return now > cooldown && now < (cooldown + this.attackWindow);
    }

    getAttackableZonesByGroup() {
        const attackableZones = {};
        
        for (const [groupName, zones] of this.groupZones) {
            const attackable = Array.from(zones).filter(zoneId => 
                this.isAttackable(zoneId)
            );
            
            if (attackable.length > 0) {
                attackableZones[groupName] = attackable;
            }
        }
        
        return attackableZones;
    }

    // Locked attack methods
    setLockedAttack(player, tag) {
        this.lockedAttacks.set(player.toLowerCase(), tag);
        this.saveZones();
    }

    getLockedAttack(player) {
        return this.lockedAttacks.get(player.toLowerCase()) || null;
    }

    clearLockedAttack(player) {
        this.lockedAttacks.delete(player.toLowerCase());
        this.saveZones();
    }
}

module.exports = new ZoneManager();